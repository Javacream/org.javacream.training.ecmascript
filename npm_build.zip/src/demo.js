/*
export default function (a, b) {
  return a + b;
};

*/

export let demo = (a, b) => {
	return a + b
}

export class Person{

constructor(name){
this.name = name
}

greet = () => {
return `Hello from ${this.name}`
}
}
